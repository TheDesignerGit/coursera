# Blogr-landing-page
using (scss and js)
Challenge by Frontend Mentor Coded by  me
