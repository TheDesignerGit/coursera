# 3rd month
## Frontend Mentor challenge

| Projects-name | Repo-link |
| ------------- | ------------- |
| 1. [Promotional Event](https://a331998513.github.io/projects/pricebox/)  | [Repo](https://github.com/a331998513/projects/tree/main/pricebox)  |
| 2. [Feature Box](https://a331998513.github.io/projects/Featurebox/) | [Repo](https://github.com/a331998513/projects/tree/main/Featurebox)  |
| 3. [Base Apparel coming soon page](https://a331998513.github.io/projects/BeautyMain/index.html) | [Repo](https://github.com/a331998513/projects/tree/main/BeautyMain) |
| 4. [fylo-data-storage-component-master](https://a331998513.github.io/projects/fylo-data-storage-component-master/) | [Repo](https://github.com/a331998513/projects/tree/main/fylo-data-storage-component-master) |
| 5. [intro-component-with-signup-form-master](https://a331998513.github.io/projects/intro-component-with-signup-form-master/) | [Repo](https://github.com/a331998513/projects/tree/main/intro-component-with-signup-form-master)|
| 6. [ping-coming-soon-page-master](https://a331998513.github.io/projects/ping-coming-soon-page-master) | [Repo](https://github.com/a331998513/projects/tree/main/ping-coming-soon-page-master) |
| 7. [coding-bootcamp-testimonials-slider-master](https://a331998513.github.io/projects/coding-bootcamp-testimonials-slider-master/) | [Repo](https://github.com/a331998513/projects/tree/main/coding-bootcamp-testimonials-slider-master)|
| 8. WIP[huddle-landing-page-with-curved-sections-master](https://a331998513.github.io/projects/huddle-landing-page-with-curved-sections-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/huddle-landing-page-with-curved-sections-master)  |


