## 4th month of 'self teaching' front end :)
Probably not self teaching? as I received tremendous help from [frontend mentor commmunity](https://www.frontendmentor.io/activity)


## Frontend Mentor challenge
I only make stuff that makes me feel proud of 😉 

| Projects-name | Repo-link |
| ------------- | ------------- |
| 1. [Promotional Event](https://a331998513.github.io/projects/pricebox/)  | [Repo](https://github.com/a331998513/projects/tree/main/pricebox)  |
| 2. [Feature Box](https://a331998513.github.io/projects/Featurebox/) | [Repo](https://github.com/a331998513/projects/tree/main/Featurebox)  |
| 3. [Base Apparel coming soon page](https://a331998513.github.io/projects/BeautyMain/index.html) | [Repo](https://github.com/a331998513/projects/tree/main/BeautyMain) |
| 4. [fylo-data-storage-component-master](https://a331998513.github.io/projects/fylo-data-storage-component-master/) | [Repo](https://github.com/a331998513/projects/tree/main/fylo-data-storage-component-master) |
| 5. [intro-component-with-signup-form-master](https://a331998513.github.io/projects/intro-component-with-signup-form-master/) | [Repo](https://github.com/a331998513/projects/tree/main/intro-component-with-signup-form-master)|
| 6. [ping-coming-soon-page-master](https://a331998513.github.io/projects/ping-coming-soon-page-master) | [Repo](https://github.com/a331998513/projects/tree/main/ping-coming-soon-page-master) |
| 7. [coding-bootcamp-testimonials-slider-master](https://a331998513.github.io/projects/coding-bootcamp-testimonials-slider-master/) | [Repo](https://github.com/a331998513/projects/tree/main/coding-bootcamp-testimonials-slider-master)|
| 8. [huddle-landing-page-with-curved-sections-master](https://a331998513.github.io/projects/huddle-landing-page-with-curved-sections-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/huddle-landing-page-with-curved-sections-master)  |
| 9. [social-media-dashboard-with-theme-switcher-master](https://a331998513.github.io/projects/social-media-dashboard-with-theme-switcher-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/social-media-dashboard-with-theme-switcher-master) |
| 10. [pricing-component-with-toggle-master](https://a331998513.github.io/projects/pricing-component-with-toggle-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/pricing-component-with-toggle-master)  |
| 11. [project-tracking-intro-component-master](https://a331998513.github.io/projects/project-tracking-intro-component-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/project-tracking-intro-component-master)  |
| 12. [clipboard-landing-page-master](https://a331998513.github.io/projects/clipboard-landing-page-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/clipboard-landing-page-master)  |
| 13. [crowdfunding-product-page-main](https://a331998513.github.io/projects/crowdfunding-product-page-main/)  | [Repo](https://github.com/a331998513/projects/tree/main/crowdfunding-product-page-main)  |
| 14. [Room homepage](https://a331998513.github.io/projects/room-homepage-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/room-homepage-master)  |
| 15. [Shortly URL shortening API Challenge](https://a331998513.github.io/projects/url-shortening-api-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/url-shortening-api-master)  |
| 16. [static-job-listings-master](https://a331998513.github.io/projects/static-job-listings-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/static-job-listings-master)  |
| 17. [IP Address Tracker](https://a331998513.github.io/projects/ip-address-tracker-master/) | [Repo](https://github.com/a331998513/projects/tree/main/ip-address-tracker-master)  |
|_Failed._ [launch-countdown-timer-main](https://a331998513.github.io/projects/launch-countdown-timer-main/) |[Repo](https://github.com/a331998513/projects/tree/main/launch-countdown-timer-main)|
| 18. [easybank-landing-page-master](https://a331998513.github.io/projects/easybank-landing-page-master/)  | [Repo](https://github.com/a331998513/projects/tree/main/easybank-landing-page-master)  |
| 19. [todo-app-main](https://a331998513.github.io/projects/todo-app-main/)  | [Repo](https://github.com/a331998513/projects/tree/main/todo-app-main)  |
| Learning node.js atm. |  |
| 99. []()  | [Repo]()  |
